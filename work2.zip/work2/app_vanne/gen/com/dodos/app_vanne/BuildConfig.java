/** Automatically generated file. DO NOT MODIFY */
package com.dodos.app_vanne;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}