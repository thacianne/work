/** Automatically generated file. DO NOT MODIFY */
package com.a.table;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}