/** Automatically generated file. DO NOT MODIFY */
package com.work.tablelayout;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}